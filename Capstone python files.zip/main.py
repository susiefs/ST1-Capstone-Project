import tensorflow
import tkinter as tk
from tkinter import filedialog
from keras.models import load_model
from PIL import Image, ImageOps
import numpy as np

# Disable scientific notation for clarity
np.set_printoptions(suppress=True)

# Load the model
model = load_model("keras_Model.h5", compile=False)

# Load the labels
class_names = open("labels.txt", "r").readlines()

def process_image(image_path):
    # Create the array of the right shape to feed into the keras model
    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

    # Load and preprocess the image
    image = Image.open(image_path).convert("RGB")
    size = (224, 224)
    image = ImageOps.fit(image, size, Image.Resampling.LANCZOS)
    image_array = np.asarray(image)
    normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1
    data[0] = normalized_image_array

    # Predict the model
    prediction = model.predict(data)
    index = np.argmax(prediction)
    class_name = class_names[index]
    confidence_score = prediction[0][index]

    return class_name[2:], confidence_score

def open_image():
    file_path = filedialog.askopenfilename(title="Select an Image")
    if file_path:
        class_name, confidence_score = process_image(r"goldenretriever1.jpg")
        result_label.config(text=f"Class: {class_name}\nConfidence Score: {confidence_score}")

# Create the main application window
root = tk.Tk()
root.title("Image Classification")

open_button = tk.Button(root, text="Open Image", command=open_image)
open_button.pack()

result_label = tk.Label(root, text="")
result_label.pack()

root.mainloop()





























