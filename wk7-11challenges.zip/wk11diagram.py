-------------------------------
|      MobilePhone            |
-------------------------------
| - _manufacturer: str        |
| - _model: str               |
| - _retail_price: float      |
-------------------------------
| + __init__(manufacturer: str,|
|      model: str,            |
|      retail_price: float)   |
| + set_manufact(manufacturer:|
|      str)                   |
| + set_model(model: str)     |
| + set_retail_price(price:   |
|      float)                 |
| + get_manufact() -> str     |
| + get_model() -> str        |
| + get_retail_price() ->     |
|      float                  |
-------------------------------
