from mobile import MobilePhone

def main():
    # Create a MobilePhone object
    phone = MobilePhone("Acme Electronics", "M1000", 199.99)

    # Display the phone's information
    print("Phone Information:")
    print("Manufacturer: ", phone.get_manufact())
    print("Model: ", phone.get_model())
    print("Retail Price: $", phone.get_retail_price())

if __name__ == "__main__":
    main()
