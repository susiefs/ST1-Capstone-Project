class LibraryItem:
    def __init__(self, item_name, author, publisher):
        self.item_name = item_name
        self.author = author
        self.publisher = publisher

    def get_item_name(self):
        return self.item_name

    def set_item_name(self, new_name):
        self.item_name = new_name

    def get_author(self):
        return self.author

    def set_author(self, new_author):
        self.author = new_author

    def get_publisher(self):
        return self.publisher

    def set_publisher(self, new_publisher):
        self.publisher = new_publisher

class Book(LibraryItem):
    def __init__(self, item_name, author, publisher, title, num_pages, has_ebook):
        super().__init__(item_name, author, publisher)
        self.title = title
        self.num_pages = num_pages
        self.has_ebook = has_ebook

    def get_title(self):
        return self.title

    def set_title(self, new_title):
        self.title = new_title

    def get_num_pages(self):
        return self.num_pages

    def set_num_pages(self, new_num_pages):
        self.num_pages = new_num_pages

    def has_ebook_version(self):
        return self.has_ebook

    def set_has_ebook_version(self, has_ebook):
        self.has_ebook = has_ebook

# Tester program
if __name__ == "__main__":
    # Creating instances of the LibraryItem class
    item1 = LibraryItem("Item 1", "Author 1", "Publisher 1")
    item2 = LibraryItem("Item 2", "Author 2", "Publisher 2")
    item3 = LibraryItem("Item 3", "Author 3", "Publisher 3")

    # Creating an instance of the Book class
    book1 = Book("Book 1", "Author 4", "Publisher 4", "Title 1", 300, True)

    # Accessor methods
    print("Item 1 Name:", item1.get_item_name())
    print("Book Title:", book1.get_title())

    # Mutator methods
    item2.set_item_name("New Item 2")
    book1.set_title("New Title 1")

    print("Updated Item 2 Name:", item2.get_item_name())
    print("Updated Book Title:", book1.get_title())
    print("Number of Pages in Book 1:", book1.get_num_pages())
    print("Has eBook Version of Book 1:", book1.has_ebook_version())
