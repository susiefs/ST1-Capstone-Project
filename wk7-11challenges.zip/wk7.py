# Program 1: Writing words to a file (console)

def write_words_to_file(file_name, num_words):
    with open(file_name, 'w') as file:
        for i in range(num_words):
            word = input(f"Enter word {i + 1}: ")
            file.write(word + '\n')
    print(f"{num_words} words written to {file_name}")

if __name__ == '__main__':
    file_name = "words.txt"
    num_words = int(input("How many words would you like to write to the file? "))
    write_words_to_file(file_name, num_words)

import tkinter as tk
from tkinter import messagebox

def analyze_words(file_name):
    with open(file_name, 'r') as file:
        words = file.read().splitlines()

    num_words = len(words)
    longest_word = max(words, key=len)
    average_length = sum(len(word) for word in words) / num_words if num_words > 0 else 0

    result_text = f"Number of words in the file: {num_words}\n"
    result_text += f"Longest word in the file: {longest_word}\n"
    result_text += f"Average length of all words: {average_length:.2f}"

    messagebox.showinfo("Word Analysis", result_text)

if __name__ == '__main__':
    file_name = "words.txt"

    # Create a simple GUI window
    window = tk.Tk()
    window.title("Word Analysis")

    analyze_button = tk.Button(window, text="Analyze Words", command=lambda: analyze_words(file_name))
    analyze_button.pack(pady=10)

    window.mainloop()
